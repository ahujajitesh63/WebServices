package com.cg.learning.webservice;

import java.net.URL;

import java.util.Scanner;

import javax.xml.namespace.QName;
import javax.xml.ws.Service;



public class Client {
	
	public static void main(String args[]) 
	{
		try
		{
		URL url = new URL("http://localhost:8083/cs?wsdl");
		
		QName qname = new QName("http://webservice.learning.cg.com/",
				"ProductDetailsService");
		
		
		Service service = Service.create(url, qname);
		
		ProductServer endPointIntf = service.getPort(ProductServer.class);
		if(endPointIntf != null )
		{
			
			
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter product Name");
		String productName = sc.nextLine();
		sc.close();
		float test=endPointIntf.productPrice(productName);
		if(test!=0){
		System.out.println("Price of product is :"+endPointIntf.productPrice(productName));
		}else{
			System.out.println("Product not found.");
		}
		}
		else
		{
			  System.out.println(" Service INF  not Created ");
		}
		
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}

}
