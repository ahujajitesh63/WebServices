package com.cg.learning.webservice;

import javax.xml.ws.Endpoint;

public class ProductPublisher {

	public static void main(String[] args) {
		 Endpoint.publish("http://127.0.0.1:8083/cs", new ProductDetails());
	      System.out.println("Web Service publised succesfully");
	      System.out.println("Press Ctrl+C to terminate Server");

	}

}
