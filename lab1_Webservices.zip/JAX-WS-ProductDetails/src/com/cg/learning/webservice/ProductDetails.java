package com.cg.learning.webservice;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.jws.WebService;

import com.cg.learning.staticdb.ProductDB;




@WebService(endpointInterface = "com.cg.learning.webservice.ProductServer")
public class ProductDetails {
	
	static HashMap<Integer, ProductBean> productMapp = ProductDB.getProductMap() ;
	List<ProductBean> list = new ArrayList<ProductBean>(productMapp.values());
	
	public float productPrice(String productNamee){
		
		float price = 0;
		
		for (ProductBean product: list){
		if(product.getProductName().equals(productNamee)){
			price = product.getProductPrice();
			break;
		}
		}
		return price;
	}

}
