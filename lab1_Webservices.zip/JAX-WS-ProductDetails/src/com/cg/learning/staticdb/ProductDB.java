package com.cg.learning.staticdb;


import java.util.HashMap;

import com.cg.learning.webservice.ProductBean;


public class ProductDB {
	
	static HashMap<Integer, ProductBean> productMap = getProductMap();
	
	
	
	
	static
	{
		
		if(productMap == null)
		{
			productMap = new HashMap<Integer , ProductBean>();
			
			ProductBean soapProduct = new ProductBean("xxsoap", 20);
			ProductBean shirtProduct = new ProductBean("xxshirt", 200);
			ProductBean shoeProduct = new ProductBean("xxshoe",2000);
			ProductBean mobileProduct = new ProductBean("xxmobile",20000);
			
			productMap.put(1, soapProduct);
			productMap.put(2, shirtProduct);
			productMap.put(3, shoeProduct);
			productMap.put(4, mobileProduct);
		}
		
		
		
	}
	
	

	public static HashMap<Integer, ProductBean> getProductMap() {
		return productMap;
	}

	public static void setProductMap(HashMap<Integer, ProductBean> productMap) {
		ProductDB.productMap = productMap;
	}

}
