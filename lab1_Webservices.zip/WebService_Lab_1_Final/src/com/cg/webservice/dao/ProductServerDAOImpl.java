package com.cg.webservice.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.jws.WebService;

import com.cg.webservice.bean.Product;
import com.cg.webservice.staticdb.ProductDB;

public class ProductServerDAOImpl implements ProductServerDAO{
	
	static HashMap<Integer, Product> productNameMap = ProductDB.getproductNameMap();
	List<Product> list = new ArrayList<Product>(productNameMap.values());
	
	public double getProduct(String pname) {
		
		double price = 0;
		for(Product productlist : list){
			if(productlist.getProductName().equals(pname)){
				price = productlist.getPrice();
				break;
			}	
		}
		return price;
		
	}

}
