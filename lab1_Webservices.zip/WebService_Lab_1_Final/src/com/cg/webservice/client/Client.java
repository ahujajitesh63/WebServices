package com.cg.webservice.client;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;

import javax.xml.namespace.QName;
import javax.xml.ws.Service;

import com.cg.webservice.dao.ProductServerDAO;
import com.cg.webservice.service.ProductServerService;

public class Client {

	public static void main(String[] args) {

		while(true){
		URL url = null;
		try {
			url = new URL("http://localhost:9876/cs?wsdl");
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// Qualified name of the service:
		// 1st arg is the service URI
		// 2nd is the service name published in the WSDL
		QName qname = new QName("http://service.webservice.cg.com/",
				"ProductServerServiceImplService");
		//Qualified Name
		// Create, in effect, a factory for the service.
		Service service = Service.create(url, qname);

		// Extract the endpoint interface, the service "port".
		ProductServerService endPointIntf = service.getPort(ProductServerService.class);

		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter Product Name");
		String pname = scanner.nextLine();
		
		if(endPointIntf.getProduct(pname) != 0){
			System.out.println("Price of the product "
					+ endPointIntf.getProduct(pname) + "\n");
		}
		else{
			System.out.println("Product does not exists!!\n");
		}
		
		}
		}

}
