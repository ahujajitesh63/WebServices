package com.cg.webservice.staticdb;

import java.util.HashMap;
import com.cg.webservice.bean.Product;

public class ProductDB {

static HashMap<Integer, Product> productNameMap = getproductNameMap();
	
	static {
		if (productNameMap == null) {
			productNameMap = new HashMap<Integer, Product>();
			Product ipad = new Product("IPad",1500);
			Product iphone = new Product("IPhone",5500);
			Product android = new Product("Android",2000);
			Product tablet = new Product("Tablet",5000);

			productNameMap.put(1, ipad);
			productNameMap.put(2, iphone);
			productNameMap.put(3, android);
			productNameMap.put(4, tablet);
		}
		
		
	}
	
	public static HashMap<Integer, Product> getproductNameMap() {
		return productNameMap;
	}
}