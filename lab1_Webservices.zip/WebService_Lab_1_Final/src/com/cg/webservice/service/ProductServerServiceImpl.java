package com.cg.webservice.service;

import javax.jws.WebService;

import com.cg.webservice.dao.ProductServerDAO;
import com.cg.webservice.dao.ProductServerDAOImpl;


@WebService(endpointInterface = "com.cg.webservice.service.ProductServerService")
public class ProductServerServiceImpl{
	
	ProductServerDAO productServerDao = new ProductServerDAOImpl();
	public double getProduct(String pname) {
		
		return productServerDao.getProduct(pname);
		
	}

}
